The org.jbox2d.util.sph package is currently being used to test the particle based fluid simulation algorithm before it is integrated with JBox2d itself.

This package is totally, absolutely, unquestionably unsupported in any way.  When it is finally stable enough to be supported, it will show up not as part of this package, but in the engine itself.

Huge thanks to Keith Vertanen and Brian Schlatter for putting together the C++ code this is based on, and generously agreeing to let us include it in Box2d/JBox2d and distribute it freely under a zlib license - without their code to start from, I never would have actually found the time to get this working.